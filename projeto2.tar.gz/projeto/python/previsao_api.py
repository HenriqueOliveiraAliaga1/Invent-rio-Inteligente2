from flask import Flask, request, jsonify
import numpy as np

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Recebe os dados enviados pelo backend
        dados = request.json.get("dados", [])

        # Converte para array NumPy
        dados = np.array(dados, dtype=float)

        # Cálculo da previsão (média * 1.1)
        previsao = float(np.mean(dados) * 1.1)

        # Retorna o resultado
        return jsonify({"previsao": round(previsao, 2)})

    except Exception as e:
        return jsonify({"erro": str(e)}), 500


@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "API Python funcionando!"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
