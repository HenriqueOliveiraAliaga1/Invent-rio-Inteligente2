// app.js - Inventário (versão avançada, integra com BackendAPI)
// Requer: backend-integration.js (que define window.BackendAPI)

class InventarioApp {
    constructor() {
        // API - usa a classe exposta em backend-integration.js
        this.api = new (window.BackendAPI || function(){throw new Error('BackendAPI não encontrado')})();
        this.useBackend = true;

        // Estado
        this.data = {
            produtos: [],
            estoque: [],
            vendas: [],
            movimentacoes: [],
            usuarios: []
        };

        this.currentPage = 'home';
        this.charts = {};

        // Inicialização
        document.addEventListener('DOMContentLoaded', () => {
            this.init();
        });
    }

    async init() {
        console.log('[app] Inicializando InventarioApp...');
        this.setupEventListeners();
        await this.loadData();
        this.loadProdutosDropdown();     // populates selects
        this.loadProdutos();             // render products table
        this.loadEstoque();              // render stock table
        this.loadVendas();               // render sales table
        this.updateStatistics();
    }

    /* ===========================
       Load / Sync Data
       =========================== */
    async loadData() {
        if (!this.useBackend) {
            this.loadLocalData();
            return;
        }

        try {
            console.log('[app] Carregando dados do backend...');
            const [produtos, estoque, vendas] = await Promise.all([
                this.api.getProdutos(),
                this.api.getEstoque(),
                this.api.getVendas()
            ]);

            // muitos backends retornam array diretamente; outros retornam { produtos: [...] }
            this.data.produtos = produtos && produtos.produtos ? produtos.produtos : (Array.isArray(produtos) ? produtos : []);
            this.data.estoque = estoque && estoque.estoque ? estoque.estoque : (Array.isArray(estoque) ? estoque : []);
            this.data.vendas = vendas && vendas.vendas ? vendas.vendas : (Array.isArray(vendas) ? vendas : []);

            console.log('[app] Dados carregados:', {
                produtos: this.data.produtos.length,
                estoque: this.data.estoque.length,
                vendas: this.data.vendas.length
            });
        } catch (err) {
            console.error('[app] Erro ao carregar do backend:', err);
            this.showNotification('Erro ao conectar com servidor. Usando dados locais.', 'warning');
            this.loadLocalData();
        }
    }

    /* ---------------------------
       Local Storage fallback
       --------------------------- */
    loadLocalData() {
        try {
            const raw = localStorage.getItem('inventarioData');
            if (!raw) {
                this.loadSampleData();
                return;
            }
            const parsed = JSON.parse(raw);
            this.data = { ...this.data, ...parsed };
            console.log('[app] Dados carregados do localStorage');
        } catch (e) {
            console.error('[app] Falha ao carregar localStorage', e);
            this.loadSampleData();
        }
    }

    saveLocalData() {
        try {
            localStorage.setItem('inventarioData', JSON.stringify(this.data));
            console.log('[app] Dados salvos localmente');
        } catch (e) {
            console.error('[app] Falha ao salvar localmente', e);
        }
    }

    loadSampleData() {
        // apenas se necessário — útil para desenvolvimento
        this.data.produtos = [
            { id: 1, nome: 'Exemplo A', descricao: 'Demo', preco: 100.0, categoria: 'Demo', data_cadastro: '2025-01-01' }
        ];
        this.data.estoque = [{ produto_id: 1, quantidade_atual: 10, quantidade_minima: 2, ultima_atualizacao: '2025-01-01' }];
        this.data.vendas = [];
        this.saveLocalData();
    }

    /* ===========================
       Eventos e listeners
       =========================== */
    setupEventListeners() {
        // Form Produto
        const formProduto = document.getElementById('formProduto');
        if (formProduto) {
            formProduto.addEventListener('submit', async (e) => {
                e.preventDefault();
                await this.handleSaveProduto();
            });
        }

        // Form Venda
        const formVenda = document.getElementById('formVenda');
        if (formVenda) {
            formVenda.addEventListener('submit', async (e) => {
                e.preventDefault();
                await this.handleSaveVenda();
            });
        }

        // Navigation links
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                this.showPage(page);
            });
        });

        // Modal close helpers (some HTML templates close modals by id)
        document.querySelectorAll('[data-close-modal]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = btn.dataset.closeModal;
                this.closeModal(id);
            });
        });

        // Toggle backend/local
        const toggleBackend = document.getElementById('toggleBackend');
        if (toggleBackend) {
            toggleBackend.addEventListener('click', () => {
                this.useBackend = !this.useBackend;
                this.showNotification(this.useBackend ? 'Modo: Backend' : 'Modo: Local', 'info');
                this.loadData().then(() => {
                    this.loadProdutos();
                    this.loadEstoque();
                    this.loadVendas();
                    this.loadProdutosDropdown();
                    this.updateStatistics();
                });
            });
        }
    }

    /* ===========================
       Produtos
       =========================== */
    async loadProdutos() {
        const tbody = document.getElementById('produtosTableBody');
        if (!tbody) return;

        const produtos = this.data.produtos || [];
        if (produtos.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted">Nenhum produto cadastrado</td></tr>`;
            return;
        }

        tbody.innerHTML = produtos.map(p => `
            <tr>
                <td>${p.id || ''}</td>
                <td><strong>${this.escapeHtml(p.nome)}</strong></td>
                <td>${p.descricao ? this.escapeHtml(p.descricao).slice(0, 60) : ''}</td>
                <td>R$ ${Number(p.preco || 0).toFixed(2)}</td>
                <td>${p.categoria || ''}</td>
                <td>${this.formatDate(p.data_cadastro)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="app.editProduto(${p.id})">Editar</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="app.deleteProduto(${p.id})">Excluir</button>
                </td>
            </tr>
        `).join('');
    }

    async handleSaveProduto() {
        const form = document.getElementById('formProduto');
        if (!form) return;

        const fd = new FormData(form);
        const id = fd.get('id') || null;
        const produto = {
            nome: fd.get('nome'),
            descricao: fd.get('descricao'),
            preco: parseFloat(fd.get('preco') || 0),
            categoria: fd.get('categoria'),
            data_cadastro: new Date().toISOString()
        };

        if (this.useBackend) {
            try {
                if (id) {
                    await this.api.updateProduto(id, produto);
                    this.showNotification('Produto atualizado no servidor', 'success');
                } else {
                    await this.api.createProduto(produto);
                    this.showNotification('Produto criado no servidor', 'success');
                }
                await this.loadData();
                this.loadProdutos();
                this.loadProdutosDropdown();
                this.updateStatistics();
                this.closeModal('modalProduto');
            } catch (err) {
                console.error('[app] Erro ao salvar produto no backend', err);
                this.showNotification('Erro ao salvar produto no servidor', 'danger');
                // fallback local
                if (!id) {
                    produto.id = this.data.produtos.length ? Math.max(...this.data.produtos.map(p=>p.id)) + 1 : 1;
                    this.data.produtos.push(produto);
                } else {
                    const idx = this.data.produtos.findIndex(p => p.id == id);
                    if (idx >= 0) this.data.produtos[idx] = {...this.data.produtos[idx], ...produto};
                }
                this.saveLocalData();
                this.loadProdutos();
            }
        } else {
            // local mode
            if (!id) {
                produto.id = this.data.produtos.length ? Math.max(...this.data.produtos.map(p=>p.id)) + 1 : 1;
                this.data.produtos.push(produto);
            } else {
                const idx = this.data.produtos.findIndex(p => p.id == id);
                if (idx >= 0) this.data.produtos[idx] = {...this.data.produtos[idx], ...produto};
            }
            this.saveLocalData();
            this.loadProdutos();
            this.updateStatistics();
            this.closeModal('modalProduto');
            this.showNotification('Produto salvo localmente', 'success');
        }
    }

    editProduto(id) {
        const produto = this.data.produtos.find(p => p.id == id);
        if (!produto) return;
        // preencher form
        const set = (sel, val) => { const el = document.getElementById(sel); if (el) el.value = val; };
        set('produtoId', produto.id);
        set('nome', produto.nome);
        set('descricao', produto.descricao);
        set('preco', produto.preco);
        set('categoria', produto.categoria);
        const modal = new bootstrap.Modal(document.getElementById('modalProduto'));
        document.getElementById('modalProdutoTitle').textContent = 'Editar Produto';
        modal.show();
    }

    async deleteProduto(id) {
        if (!confirm('Tem certeza que quer excluir este produto?')) return;

        if (this.useBackend) {
            try {
                await this.api.deleteProduto(id);
                this.showNotification('Produto excluído no servidor', 'success');
                await this.loadData();
                this.loadProdutos();
                this.loadEstoque();
            } catch (err) {
                console.error('[app] Erro ao deletar no backend', err);
                this.showNotification('Erro ao excluir no servidor', 'danger');
            }
        } else {
            this.data.produtos = this.data.produtos.filter(p => p.id != id);
            this.data.estoque = this.data.estoque.filter(e => e.produto_id != id);
            this.saveLocalData();
            this.loadProdutos();
            this.loadEstoque();
            this.showNotification('Produto excluído localmente', 'success');
        }
    }

    /* ===========================
       Estoque
       =========================== */
    async loadEstoque() {
        const tbody = document.getElementById('estoqueTableBody');
        if (!tbody) return;

        const estoque = this.data.estoque || [];
        if (!estoque.length) {
            tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted">Nenhum item de estoque</td></tr>`;
            return;
        }

        tbody.innerHTML = estoque.map(item => {
            const produto = this.data.produtos.find(p => p.id == item.produto_id) || {};
            const status = (item.quantidade_atual <= item.quantidade_minima) ? 'table-warning' : '';
            return `
                <tr class="${status}">
                    <td>${this.escapeHtml(produto.nome || 'Produto não encontrado')}</td>
                    <td>${produto.categoria || ''}</td>
                    <td>${item.quantidade_atual}</td>
                    <td>${item.quantidade_minima}</td>
                    <td>${this.formatDate(item.ultima_atualizacao)}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="app.openAjusteEstoque(${item.produto_id})">Ajustar</button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    openAjusteEstoque(produtoId) {
        const el = document.getElementById('produtoAjusteId');
        if (el) el.value = produtoId;
        const modal = new bootstrap.Modal(document.getElementById('modalAjusteEstoque'));
        modal.show();
    }

    async handleAjusteEstoque(form) {
        // espera receber o form HTML element
        const fd = new FormData(form);
        const produtoId = parseInt(fd.get('produto_id'));
        const novaQuantidade = parseInt(fd.get('quantidade'));
        if (isNaN(produtoId) || isNaN(novaQuantidade)) {
            this.showNotification('Dados inválidos', 'danger');
            return;
        }

        const payload = { quantidade: novaQuantidade };
        if (this.useBackend) {
            try {
                await this.api.updateEstoque(produtoId, payload);
                this.showNotification('Estoque atualizado no servidor', 'success');
                await this.loadData();
                this.loadEstoque();
            } catch (err) {
                console.error('[app] Erro ao atualizar estoque no backend', err);
                this.showNotification('Erro ao atualizar estoque no servidor', 'danger');
            }
        } else {
            const item = this.data.estoque.find(e => e.produto_id == produtoId);
            if (item) {
                item.quantidade_atual = novaQuantidade;
                item.ultima_atualizacao = new Date().toISOString().split('T')[0];
            } else {
                this.data.estoque.push({ produto_id: produtoId, quantidade_atual: novaQuantidade, quantidade_minima: 0, ultima_atualizacao: new Date().toISOString().split('T')[0] });
            }
            this.saveLocalData();
            this.loadEstoque();
            this.showNotification('Estoque atualizado localmente', 'success');
        }
    }

    /* ===========================
       Vendas
       =========================== */
    async loadVendas() {
        const tbody = document.getElementById('vendasTableBody');
        if (!tbody) return;

        const vendas = this.data.vendas || [];
        if (!vendas.length) {
            tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">Nenhuma venda registrada</td></tr>`;
            return;
        }

        tbody.innerHTML = vendas.map(v => {
            const produto = this.data.produtos.find(p => p.id == v.produto_id) || {};
            return `
                <tr>
                    <td>${v.id}</td>
                    <td>${this.escapeHtml(produto.nome || 'Produto não encontrado')}</td>
                    <td>${v.quantidade}</td>
                    <td>R$ ${Number(v.preco_unitario || 0).toFixed(2)}</td>
                    <td>R$ ${Number(v.total || 0).toFixed(2)}</td>
                    <td>${this.escapeHtml(v.cliente || '')}</td>
                    <td>${this.formatDate(v.data_venda)}</td>
                    <td><button class="btn btn-sm btn-outline-danger" onclick="app.deleteVenda(${v.id})">Excluir</button></td>
                </tr>
            `;
        }).join('');
    }

    async handleSaveVenda() {
        const form = document.getElementById('formVenda');
        if (!form) return;
        const fd = new FormData(form);
        const produtoId = parseInt(fd.get('produto_id'));
        const quantidade = parseInt(fd.get('quantidade'));
        const precoUnitario = parseFloat(fd.get('preco_unitario'));
        const cliente = fd.get('cliente') || 'Cliente';

        if (!produtoId || isNaN(quantidade) || isNaN(precoUnitario)) {
            this.showNotification('Preencha os campos corretamente', 'danger');
            return;
        }

        const total = quantidade * precoUnitario;
        const venda = {
            produto_id: produtoId,
            quantidade,
            preco_unitario: precoUnitario,
            total,
            cliente,
            data_venda: new Date().toISOString().split('T')[0]
        };

        // check estoque
        const estoqueItem = this.data.estoque.find(e => e.produto_id == produtoId);
        if (!estoqueItem || estoqueItem.quantidade_atual < quantidade) {
            this.showNotification('Estoque insuficiente', 'danger');
            return;
        }

        if (this.useBackend) {
            try {
                await this.api.createVenda(venda);
                this.showNotification('Venda registrada no servidor', 'success');
                await this.loadData();
                this.loadVendas();
                this.loadEstoque();
                this.closeModal('modalVenda');
            } catch (err) {
                console.error('[app] Erro ao criar venda no backend', err);
                this.showNotification('Erro ao registrar venda no servidor', 'danger');
            }
        } else {
            venda.id = this.data.vendas.length ? Math.max(...this.data.vendas.map(v=>v.id)) + 1 : 1;
            this.data.vendas.push(venda);
            estoqueItem.quantidade_atual -= quantidade;
            estoqueItem.ultima_atualizacao = venda.data_venda;
            this.saveLocalData();
            this.loadVendas();
            this.loadEstoque();
            this.closeModal('modalVenda');
            this.showNotification('Venda salva localmente', 'success');
        }
    }

    async deleteVenda(id) {
        if (!confirm('Excluir venda?')) return;
        if (this.useBackend) {
            try {
                await this.api.deleteVenda(id);
                await this.loadData();
                this.loadVendas();
                this.showNotification('Venda excluída', 'success');
            } catch (err) {
                console.error('[app] Erro ao excluir venda no backend', err);
                this.showNotification('Erro ao excluir venda no servidor', 'danger');
            }
        } else {
            this.data.vendas = this.data.vendas.filter(v => v.id != id);
            this.saveLocalData();
            this.loadVendas();
            this.showNotification('Venda excluída localmente', 'success');
        }
    }

    /* ===========================
       UI Helpers
       =========================== */
    showNotification(message, type = 'info') {
        // type: success, danger, warning, info
        console.log(`[NOTIF ${type}] ${message}`);
        // minimal visual toast fallback
        const containerId = 'notification-container';
        let container = document.getElementById(containerId);
        if (!container) {
            container = document.createElement('div');
            container.id = containerId;
            container.style.position = 'fixed';
            container.style.right = '20px';
            container.style.top = '20px';
            container.style.zIndex = 9999;
            document.body.appendChild(container);
        }
        const el = document.createElement('div');
        el.className = `toast align-items-center text-bg-${type === 'danger' ? 'danger' : (type === 'success' ? 'success' : (type === 'warning' ? 'warning' : 'info'))} border-0 mb-2`;
        el.setAttribute('role','alert');
        el.innerHTML = `<div class="d-flex"><div class="toast-body">${this.escapeHtml(message)}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" aria-label="Close"></button></div>`;
        container.appendChild(el);

        const closeBtn = el.querySelector('.btn-close');
        if (closeBtn) closeBtn.addEventListener('click', () => el.remove());

        setTimeout(()=> { el.remove(); }, 5000);
    }

    closeModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        try {
            const modal = bootstrap.Modal.getInstance(el) || new bootstrap.Modal(el);
            modal.hide();
        } catch (e) {
            console.warn('[app] Erro ao fechar modal', e);
        }
    }

    formatDate(value) {
        if (!value) return '';
        try {
            const d = new Date(value);
            return d.toLocaleDateString('pt-BR');
        } catch {
            return String(value);
        }
    }

    escapeHtml(str = '') {
        return String(str)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');
    }

    /* ===========================
       UI utilities (selects, stats)
       =========================== */
    loadProdutosDropdown() {
        const selects = document.querySelectorAll('select[data-produtos]');
        selects.forEach(sel => {
            sel.innerHTML = `<option value="">Selecione</option>` + (this.data.produtos || []).map(p => {
                const estoque = this.data.estoque.find(e => e.produto_id == p.id);
                const info = estoque ? ` (Estoque: ${estoque.quantidade_atual})` : '';
                return `<option value="${p.id}">${this.escapeHtml(p.nome)}${info}</option>`;
            }).join('');
        });
    }

    updateStatistics() {
        // minimal: total produtos, total vendas, estoque baixo
        const totalProdutos = (this.data.produtos || []).length;
        const totalVendas = (this.data.vendas || []).reduce((s,v)=>s + (v.total || 0), 0);
        const estoqueBaixo = (this.data.estoque || []).filter(e => e.quantidade_atual <= e.quantidade_minima).length;

        const elTotal = document.getElementById('dashboardTotalProdutos');
        const elVendas = document.getElementById('dashboardReceitaTotal');
        const elBaixo = document.getElementById('dashboardEstoqueBaixo');

        if (elTotal) elTotal.textContent = totalProdutos;
        if (elVendas) elVendas.textContent = `R$ ${totalVendas.toFixed(2)}`;
        if (elBaixo) elBaixo.textContent = estoqueBaixo;
    }
}

/* ===========================
   Instancia global
   =========================== */
window.app = new InventarioApp();

/* ===========================
   Expose helper for forms in HTML that call ajusta estoque
   =========================== */
window.appHandleAjusteEstoque = function(formId) {
    const f = document.getElementById(formId);
    if (!f) return;
    app.handleAjusteEstoque(f);
};
