# Integração com Backend - Sistema de Inventário Inteligente

## 📋 Visão Geral

O sistema está preparado para integração com backend através de uma classe API dedicada. O frontend pode funcionar tanto em modo local (localStorage) quanto em modo backend (API REST).

## 🔧 Configuração

### 1. Ativar Modo Backend

```javascript
// No console do navegador ou no código
window.app.setBackendMode(true, 'http://localhost:3001/produtos');
```

### 2. Configurar URL do Backend

```javascript
// Alterar a URL base da API
window.app.api.baseURL = 'https://seu-backend.com/api';
```

## 🌐 Endpoints Esperados

### Autenticação
- `POST /auth/login` - Login do usuário
- `POST /auth/register` - Registro de usuário
- `POST /auth/logout` - Logout (opcional)

### Produtos
- `GET /produtos` - Listar produtos
- `POST /produtos` - Criar produto
- `PUT /produtos/:id` - Atualizar produto
- `DELETE /produtos/:id` - Excluir produto

### Estoque
- `GET /estoque` - Listar estoque
- `PUT /estoque` - Atualizar estoque

### Vendas
- `GET /vendas` - Listar vendas
- `POST /vendas` - Criar venda
- `DELETE /vendas/:id` - Excluir venda

## 📝 Estrutura de Dados

### Produto
```json
{
  "id": 1,
  "nome": "Nome do Produto",
  "descricao": "Descrição do produto",
  "preco": 99.99,
  "categoria": "Categoria",
  "data_cadastro": "2024-01-01"
}
```

### Estoque
```json
{
  "id": 1,
  "produto_id": 1,
  "quantidade": 100,
  "quantidade_minima": 10,
  "localizacao": "A1-B2"
}
```

### Venda
```json
{
  "id": 1,
  "produto_id": 1,
  "quantidade": 2,
  "preco_unitario": 99.99,
  "total": 199.98,
  "cliente": "Nome do Cliente",
  "data_venda": "2024-01-01"
}
```

### Usuário (Login/Registro)
```json
{
  "id": 1,
  "nome": "Nome",
  "sobrenome": "Sobrenome",
  "email": "email@exemplo.com",
  "senha": "senha123"
}
```

## 🔐 Autenticação

O sistema espera um token JWT retornado no login:

```json
{
  "token": "jwt_token_aqui",
  "user": {
    "id": 1,
    "nome": "Nome",
    "email": "email@exemplo.com"
  }
}
```

O token será automaticamente incluído nos headers das requisições:
```
Authorization: Bearer jwt_token_aqui
```

## 🚀 Como Usar

### 1. Modo Local (Padrão)
O sistema funciona normalmente com localStorage.

### 2. Modo Backend
```javascript
// Ativar modo backend
window.app.setBackendMode(true, 'http://localhost:3000/api');

// Recarregar dados do backend
await window.app.loadData();
```

### 3. Alternar entre Modos
```javascript
// Voltar para modo local
window.app.setBackendMode(false);
```

## ⚠️ Tratamento de Erros

O sistema possui fallback automático:
- Se o backend estiver indisponível, volta para modo local
- Notificações de erro são exibidas ao usuário
- Logs detalhados no console para debugging

## 🔄 Sincronização

### Carregamento de Dados
- `loadData()` - Carrega dados do backend ou localStorage
- `loadLocalData()` - Força carregamento do localStorage

### Salvamento de Dados
- `saveData()` - Salva no backend ou localStorage
- `saveLocalData()` - Força salvamento no localStorage

## 📊 Monitoramento

### Logs Disponíveis
- Carregamento de dados
- Salvamento de dados
- Requisições de API
- Erros de conexão

### Console Commands
```javascript
// Verificar modo atual
console.log(window.app.useBackend);

// Ver dados atuais
console.log(window.app.data);

// Ver configuração da API
console.log(window.app.api.baseURL);
```

## 🛠️ Desenvolvimento

### Adicionar Novos Endpoints
1. Adicionar método na classe `API`
2. Modificar função correspondente na classe `InventarioApp`
3. Adicionar tratamento de erro

### Exemplo de Novo Endpoint
```javascript
// Na classe API
async getRelatorios() {
    return this.request('/relatorios');
}

// Na classe InventarioApp
async loadRelatorios() {
    if (this.useBackend) {
        try {
            this.data.relatorios = await this.api.getRelatorios();
        } catch (error) {
            console.error('Erro ao carregar relatórios:', error);
        }
    }
}
```

---

**Nota:** O sistema está configurado para funcionar perfeitamente em modo local. A integração com backend é opcional e pode ser ativada quando necessário.
