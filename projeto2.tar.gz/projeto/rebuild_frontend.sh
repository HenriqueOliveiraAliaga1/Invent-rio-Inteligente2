#!/bin/bash

echo "🔧 Construindo frontend..."
docker compose build frontend

echo "🛑 Derrubando containers..."
docker compose down

echo "🚀 Subindo containers..."
docker compose up -d

echo "✅ Frontend reconstruído e projeto reiniciado!"
