import mongoose from "mongoose";

const vendaSchema = new mongoose.Schema({
  produto: { type: String, required: true },
  quantidade: { type: Number, required: true },
  data: { type: Date, default: Date.now }
});

export default mongoose.model("Venda", vendaSchema);
