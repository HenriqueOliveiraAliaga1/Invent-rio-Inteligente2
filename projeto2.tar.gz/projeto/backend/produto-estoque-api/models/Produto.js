const mongoose = require('mongoose');

const produtoSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'Nome do produto é obrigatório'],
    trim: true
  },
  preco: {
    type: Number,
    required: [true, 'Preço do produto é obrigatório'],
    min: [0, 'Preço não pode ser negativo']
  },
  quantidade: {
    type: Number,
    required: [true, 'Quantidade em estoque é obrigatória'],
    min: [0, 'Quantidade não pode ser negativa'],
    default: 0
  }
}, {
  timestamps: true
});

// Método para atualizar estoque
produtoSchema.methods.atualizarEstoque = function(quantidade, operacao = 'saida') {
  if (operacao === 'entrada') {
    this.quantidade += quantidade;
  } else if (operacao === 'saida') {
    if (this.quantidade >= quantidade) {
      this.quantidade -= quantidade;
    } else {
      throw new Error('Estoque insuficiente');
    }
  }
  return this.save();
};

module.exports = mongoose.model('Produto', produtoSchema);
