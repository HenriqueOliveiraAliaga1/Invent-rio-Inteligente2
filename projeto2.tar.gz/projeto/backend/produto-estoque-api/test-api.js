// Script simples para testar a API
const axios = require('axios');

const BASE_URL = 'http://localhost:3000';

async function testarAPI() {
  try {
    console.log('🧪 Iniciando testes da API...\n');

    // Teste 1: Verificar se o servidor está rodando
    console.log('1. Testando conexão com servidor...');
    const response = await axios.get(BASE_URL);
    console.log('✅ Servidor respondendo:', response.data.message);

    // Teste 2: Criar um produto
    console.log('\n2. Criando produto de teste...');
    const novoProduto = {
      nome: 'Produto Teste',
      preco: 99.99,
      quantidade: 50
    };
    
    const produtoCriado = await axios.post(`${BASE_URL}/produtos`, novoProduto);
    console.log('✅ Produto criado:', produtoCriado.data);
    const produtoId = produtoCriado.data._id;

    // Teste 3: Listar produtos
    console.log('\n3. Listando produtos...');
    const produtos = await axios.get(`${BASE_URL}/produtos`);
    console.log('✅ Produtos encontrados:', produtos.data.length);

    // Teste 4: Buscar produto por ID
    console.log('\n4. Buscando produto por ID...');
    const produto = await axios.get(`${BASE_URL}/produtos/${produtoId}`);
    console.log('✅ Produto encontrado:', produto.data.nome);

    // Teste 5: Atualizar estoque (simular venda)
    console.log('\n5. Simulando venda (saída de estoque)...');
    const estoqueAtualizado = await axios.put(`${BASE_URL}/produtos/${produtoId}/estoque`, {
      quantidade: 5,
      operacao: 'saida'
    });
    console.log('✅ Estoque atualizado. Nova quantidade:', estoqueAtualizado.data.quantidade);

    // Teste 6: Atualizar produto
    console.log('\n6. Atualizando produto...');
    const produtoAtualizado = await axios.put(`${BASE_URL}/produtos/${produtoId}`, {
      nome: 'Produto Teste Atualizado',
      preco: 149.99,
      quantidade: 45
    });
    console.log('✅ Produto atualizado:', produtoAtualizado.data.nome);

    console.log('\n🎉 Todos os testes passaram com sucesso!');

  } catch (error) {
    console.error('❌ Erro no teste:', error.response?.data || error.message);
  }
}

// Executar testes apenas se o arquivo for chamado diretamente
if (require.main === module) {
  console.log('⚠️  Certifique-se de que o servidor está rodando (npm run dev) antes de executar os testes!\n');
  setTimeout(testarAPI, 2000); // Aguarda 2 segundos para dar tempo do servidor iniciar
}

module.exports = testarAPI;
