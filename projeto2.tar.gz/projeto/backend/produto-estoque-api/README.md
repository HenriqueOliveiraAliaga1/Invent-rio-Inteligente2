## Pré-requisitos

- Node.js (versão 14 ou superior)
- MongoDB instalado e rodando localmente
- npm ou yarn

## Instalação

1. Clone ou baixe o projeto
2. Instale as dependências:
```bash
npm install
```

3. Certifique que o MongoDB está rodando localmente na porta padrão (27017) se não dá ruim

4. Inicie o servidor:
```bash
# Modo desenvolvimento (com nodemon)
npm run dev

# Modo produção
npm start
```

O servidor estará rodando em `http://localhost:3000`

## Endpoints da API

### Produtos

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/produtos` | Listar todos os produtos |
| GET | `/produtos/:id` | Buscar produto por ID |
| POST | `/produtos` | Criar novo produto |
| PUT | `/produtos/:id` | Atualizar produto |
| DELETE | `/produtos/:id` | Excluir produto |
| PUT | `/produtos/:id/estoque` | Atualizar estoque |

### Exemplos de Uso

#### Criar Produto
```bash
POST /produtos
Content-Type: application/json

{
  "nome": "Notebook Dell",
  "preco": 2500.00,
  "quantidade": 10
}
```

#### Listar Produtos
```bash
GET /produtos
```

#### Atualizar Estoque
```bash
PUT /produtos/:id/estoque
Content-Type: application/json

{
  "quantidade": 5,
  "operacao": "saida"  // ou "entrada"
}
```

## Estrutura do Projeto

```
produto-estoque-api/
├── config/
│   └── database.js      # Configuração do MongoDB
├── controllers/
│   └── produtoController.js  # Lógica de negócio
├── models/
│   └── Produto.js       # Schema do produto
├── routes/
│   └── produtos.js      # Rotas da API
├── .env                 # Variáveis de ambiente
├── package.json         # Dependências
├── server.js           # Arquivo principal
└── README.md           # Documentação
```

## Modelo de Dados

### Produto
```javascript
{
  nome: String,        // Nome do produto (obrigatório)
  preco: Number,       // Preço (obrigatório, >= 0)
  quantidade: Number,  // Quantidade em estoque (>= 0)
  createdAt: Date,     // Data de criação
  updatedAt: Date      // Data de atualização
}
```

## Funcionalidades Especiais

- **Controle de Estoque**: Método automático para entrada/saída de produtos
- **Validações**: Preços e quantidades não podem ser negativos
- **Timestamps**: Criação e atualização automáticas
- **Tratamento de Erros**: Respostas padronizadas para erros

## Integração com Sistema de Vendas

Para integrar com o sistema de vendas, use o endpoint de atualização de estoque:

```javascript
// Exemplo: Registrar venda de 3 unidades
PUT /produtos/PRODUTO_ID/estoque
{
  "quantidade": 3,
  "operacao": "saida"
}
```

## Tecnologias Utilizadas

- **Node.js**: Runtime JavaScript
- **Express**: Framework web
- **MongoDB**: Banco de dados NoSQL
- **Mongoose**: ODM para MongoDB
- **CORS**: Middleware para requisições cross-origin
- **dotenv**: Gerenciamento de variáveis de ambiente
