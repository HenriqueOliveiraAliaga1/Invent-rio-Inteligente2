import { spawn } from "child_process";
import path from "path";
import Venda from "../models/Venda.js";

// 📦 Registrar nova venda
export const registrarVenda = async (req, res) => {
  try {
    const novaVenda = new Venda(req.body);
    await novaVenda.save();
    res.status(201).json(novaVenda);
  } catch (error) {
    console.error("Erro ao registrar venda:", error);
    res.status(500).json({ erro: "Erro ao registrar venda" });
  }
};

// 📋 Listar histórico de vendas
export const listarVendas = async (req, res) => {
  try {
    const vendas = await Venda.find().sort({ data: 1 });
    res.json(vendas);
  } catch (error) {
    console.error("Erro ao listar vendas:", error);
    res.status(500).json({ erro: "Erro ao listar vendas" });
  }
};

// 🔮 Previsão de vendas (Node ↔ Python)
export const preverVendas = async (req, res) => {
  try {
    // Buscar histórico no banco
    const historico = await Venda.find({}, { _id: 0, data: 1, quantidade: 1 });

    // Caminho correto até o script Python dentro de /vendas-api/
    const pythonPath = path.join(process.cwd(), "vendas-api", "previsao.py");

    // Executar script Python
    const python = spawn("python3", [pythonPath]);

    let dataString = "";

    // Enviar dados ao Python
    python.stdin.write(JSON.stringify(historico));
    python.stdin.end();

    // Capturar saída do Python
    python.stdout.on("data", (data) => {
      dataString += data.toString();
    });

    // Capturar erros do Python
    python.stderr.on("data", (data) => {
      console.error("Erro Python:", data.toString());
    });

    // Quando o script terminar
    python.on("close", () => {
      try {
        const output = JSON.parse(dataString);
        res.json(output);
      } catch (err) {
        console.error("Erro ao processar saída do Python:", err);
        res.status(500).json({ erro: "Falha ao processar previsão" });
      }
    });
  } catch (error) {
    console.error("Erro geral na previsão:", error);
    res.status(500).json({ erro: "Erro ao buscar histórico de vendas" });
  }
};

