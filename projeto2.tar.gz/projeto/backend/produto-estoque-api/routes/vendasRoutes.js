import express from "express";
import { registrarVenda, listarVendas, preverVendas } from "../controllers/vendasController.js";

const router = express.Router();

// Rotas principais
router.post("/", registrarVenda);
router.get("/", listarVendas);
router.get("/previsao", preverVendas);

export default router;

