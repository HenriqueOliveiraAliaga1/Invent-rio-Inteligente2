const express = require("express");
const router = express.Router();
const Produto = require("../models/Produto");

// Listar produtos
router.get("/", async (req, res) => {
    try {
        const produtos = await Produto.find();
        res.json(produtos);
    } catch (error) {
        res.status(500).json({ error: "Erro ao listar produtos" });
    }
});

// Buscar por ID
router.get("/:id", async (req, res) => {
    try {
        const produto = await Produto.findById(req.params.id);
        if (!produto) return res.status(404).json({ error: "Produto não encontrado" });
        res.json(produto);
    } catch {
        res.status(500).json({ error: "Erro na busca do produto" });
    }
});

// Criar produto
router.post("/", async (req, res) => {
    try {
        const produto = new Produto(req.body);
        await produto.save();
        res.status(201).json(produto);
    } catch (error) {
        res.status(400).json({ error: "Erro ao criar produto" });
    }
});

// Atualizar produto
router.put("/:id", async (req, res) => {
    try {
        const produto = await Produto.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(produto);
    } catch {
        res.status(400).json({ error: "Erro ao atualizar produto" });
    }
});

// Atualizar estoque
router.put("/:id/estoque", async (req, res) => {
    try {
        const { quantidade, operacao } = req.body;
        const produto = await Produto.findById(req.params.id);

        if (!produto) return res.status(404).json({ error: "Produto não encontrado" });

        if (operacao === "entrada") produto.quantidade += quantidade;
        if (operacao === "saida") produto.quantidade -= quantidade;

        await produto.save();
        res.json(produto);
    } catch (error) {
        res.status(400).json({ error: "Erro ao atualizar estoque" });
    }
});

// Excluir produto
router.delete("/:id", async (req, res) => {
    try {
        await Produto.findByIdAndDelete(req.params.id);
        res.json({ message: "Produto excluído" });
    } catch {
        res.status(500).json({ error: "Erro ao excluir produto" });
    }
});

module.exports = router;
