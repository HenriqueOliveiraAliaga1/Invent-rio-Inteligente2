const express = require("express");
const cors = require("cors");
const connectDB = require("./config/database");
require("dotenv").config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas
app.use("/produtos", require("./routes/produtos"));

// Conecta ao MongoDB
connectDB();

// Inicia servidor
app.listen(process.env.PORT || 3001, () =>
    console.log("API rodando na porta", process.env.PORT || 3001)
);
