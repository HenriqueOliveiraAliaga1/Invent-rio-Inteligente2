#!/bin/bash

sudo mkdir -p /opt/projeto
sudo cp -r ../* /opt/projeto

sudo tee /etc/systemd/system/projeto.service <<EOF
[Unit]
Description=Projeto Inventário Inteligente
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
WorkingDirectory=/opt/projeto
ExecStart=/usr/bin/docker-compose up -d
ExecStop=/usr/bin/docker-compose down
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable projeto
sudo systemctl start projeto

echo "Deploy concluído!"
